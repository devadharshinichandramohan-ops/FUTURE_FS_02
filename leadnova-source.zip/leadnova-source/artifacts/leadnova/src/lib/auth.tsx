import React, { createContext, useContext, useEffect, useState } from "react";
import { setAuthTokenGetter } from "@workspace/api-client-react";
import { useGetCurrentUser } from "@workspace/api-client-react";

type AuthContextType = {
  token: string | null;
  user: any | null;
  isLoading: boolean;
  login: (token: string) => void;
  logout: () => void;
};

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [token, setToken] = useState<string | null>(() => localStorage.getItem("leadnova_token"));
  
  // Sync token to API client getter
  useEffect(() => {
    setAuthTokenGetter(() => token);
  }, [token]);

  const { data: user, isLoading: isUserLoading, isError } = useGetCurrentUser({
    query: {
      enabled: !!token,
      retry: false,
      queryKey: ["auth", "me", token],
    },
  });

  const login = (newToken: string) => {
    localStorage.setItem("leadnova_token", newToken);
    setToken(newToken);
  };

  const logout = () => {
    localStorage.removeItem("leadnova_token");
    setToken(null);
  };

  useEffect(() => {
    if (isError) {
      logout();
    }
  }, [isError]);

  return (
    <AuthContext.Provider
      value={{
        token,
        user: user || null,
        isLoading: !!token && isUserLoading,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
