import React from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/lib/auth";
import { 
  LayoutDashboard, 
  Users, 
  LogOut, 
  Sparkles,
  Command,
  ChevronUp
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export function Sidebar() {
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const navItems = [
    { label: "Dashboard", href: "/dashboard", icon: LayoutDashboard },
    { label: "Leads", href: "/leads", icon: Users },
  ];

  return (
    <div className="flex h-screen w-64 flex-col border-r bg-white">
      {/* Brand */}
      <div className="flex h-16 items-center gap-2 border-b px-6">
        <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-primary text-primary-foreground">
          <Command className="h-5 w-5" />
        </div>
        <span className="text-lg font-bold tracking-tight">LeadNova</span>
      </div>

      {/* Nav */}
      <div className="flex-1 overflow-y-auto py-4">
        <nav className="grid gap-1 px-3">
          {navItems.map((item) => {
            const isActive = location === item.href || (location === "/" && item.href === "/dashboard") || (location.startsWith("/leads") && item.href === "/leads");
            return (
              <Link key={item.href} href={item.href}>
                <div
                  className={cn(
                    "flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors hover:bg-gray-100 hover:text-gray-900 cursor-pointer",
                    isActive ? "bg-gray-100 text-gray-900" : "text-gray-500"
                  )}
                >
                  <item.icon className={cn("h-4 w-4", isActive ? "text-primary" : "text-gray-400")} />
                  {item.label}
                </div>
              </Link>
            );
          })}
        </nav>
      </div>

      {/* Pro Plan Card */}
      <div className="p-4">
        <div className="rounded-xl border bg-gray-50/50 p-4">
          <div className="flex items-center gap-2 mb-2">
            <Sparkles className="h-4 w-4 text-amber-500" />
            <h4 className="text-sm font-semibold">Pro Plan</h4>
          </div>
          <p className="text-xs text-gray-500 mb-3">You're on the Pro plan. You have unlimited leads.</p>
          <Button variant="outline" size="sm" className="w-full text-xs bg-white">
            Manage Billing
          </Button>
        </div>
      </div>

      {/* User Profile */}
      <div className="border-t p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Avatar className="h-9 w-9 border border-gray-200">
              <AvatarFallback className="bg-primary/10 text-primary text-xs font-medium">
                {user?.name?.charAt(0) || "U"}
              </AvatarFallback>
            </Avatar>
            <div className="flex flex-col">
              <span className="text-sm font-medium leading-none mb-1">{user?.name || "Admin User"}</span>
              <span className="text-xs text-gray-500 leading-none">{user?.email || "admin@leadnova.com"}</span>
            </div>
          </div>
          <Button variant="ghost" size="icon" className="h-8 w-8 text-gray-500 hover:text-gray-900" onClick={logout}>
            <LogOut className="h-4 w-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
