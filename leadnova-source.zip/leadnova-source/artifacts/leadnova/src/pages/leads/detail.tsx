import { useState } from "react";
import { Link, useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import {
  useGetLead,
  useUpdateLead,
  useAddLeadNote,
  getGetLeadQueryKey,
  getListLeadsQueryKey,
  getGetAnalyticsSummaryQueryKey,
  getGetRecentActivityQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  ArrowLeft,
  Mail,
  Tag,
  Calendar,
  MessageSquare,
  Send,
} from "lucide-react";
import { format, formatDistanceToNow } from "date-fns";
import { toast } from "sonner";

const statusBadge: Record<string, string> = {
  new: "bg-blue-50 text-blue-700 border-blue-200",
  contacted: "bg-amber-50 text-amber-700 border-amber-200",
  converted: "bg-emerald-50 text-emerald-700 border-emerald-200",
};

export default function LeadDetail({ id }: { id: string }) {
  const qc = useQueryClient();
  const [, setLocation] = useLocation();
  const [noteText, setNoteText] = useState("");

  const { data: lead, isLoading } = useGetLead(id, {
    query: { enabled: !!id, queryKey: getGetLeadQueryKey(id) },
  });

  const invalidate = () => {
    qc.invalidateQueries({ queryKey: getGetLeadQueryKey(id) });
    qc.invalidateQueries({ queryKey: getListLeadsQueryKey() });
    qc.invalidateQueries({ queryKey: getGetAnalyticsSummaryQueryKey() });
    qc.invalidateQueries({ queryKey: getGetRecentActivityQueryKey() });
  };

  const updateMut = useUpdateLead({
    mutation: {
      onSuccess: () => {
        toast.success("Status updated");
        invalidate();
      },
      onError: (e) => toast.error(e.message ?? "Failed to update"),
    },
  });

  const addNoteMut = useAddLeadNote({
    mutation: {
      onSuccess: () => {
        toast.success("Note added");
        setNoteText("");
        invalidate();
      },
      onError: (e) => toast.error(e.message ?? "Failed to add note"),
    },
  });

  if (isLoading) {
    return (
      <div className="px-8 py-8 max-w-[1200px] mx-auto space-y-6">
        <Skeleton className="h-8 w-32" />
        <Skeleton className="h-32 w-full" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-64 w-full lg:col-span-2" />
        </div>
      </div>
    );
  }

  if (!lead) {
    return (
      <div className="px-8 py-16 text-center">
        <p className="text-sm text-gray-600">Lead not found.</p>
        <Button
          variant="outline"
          className="mt-4"
          onClick={() => setLocation("/leads")}
        >
          Back to leads
        </Button>
      </div>
    );
  }

  return (
    <div className="px-8 py-8 max-w-[1200px] mx-auto">
      <Link href="/leads">
        <Button
          variant="ghost"
          size="sm"
          className="mb-4 text-gray-500 hover:text-gray-900 -ml-2"
          data-testid="button-back"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to leads
        </Button>
      </Link>

      <Card className="border-gray-200/80 shadow-sm mb-6">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
            <div className="flex items-center gap-4">
              <div className="h-14 w-14 rounded-full bg-gradient-to-br from-indigo-100 to-indigo-200 flex items-center justify-center text-xl font-semibold text-indigo-700">
                {lead.name.charAt(0).toUpperCase()}
              </div>
              <div>
                <h1 className="text-xl font-bold text-gray-900" data-testid="text-lead-name">
                  {lead.name}
                </h1>
                <p className="text-sm text-gray-500 flex items-center gap-1.5 mt-0.5">
                  <Mail className="h-3.5 w-3.5" />
                  {lead.email}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <Badge
                variant="outline"
                className={`text-xs capitalize border ${statusBadge[lead.status]}`}
              >
                {lead.status}
              </Badge>
              <Select
                value={lead.status}
                onValueChange={(v) =>
                  updateMut.mutate({
                    id: lead.id,
                    data: { status: v as "new" | "contacted" | "converted" },
                  })
                }
              >
                <SelectTrigger className="h-9 w-[160px]" data-testid="select-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="contacted">Contacted</SelectItem>
                  <SelectItem value="converted">Converted</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="border-gray-200/80 shadow-sm h-fit">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Lead details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-sm">
            <DetailRow
              icon={<Mail className="h-4 w-4" />}
              label="Email"
              value={lead.email}
            />
            <DetailRow
              icon={<Tag className="h-4 w-4" />}
              label="Source"
              value={<span className="capitalize">{lead.source}</span>}
            />
            <DetailRow
              icon={<Calendar className="h-4 w-4" />}
              label="Created"
              value={format(new Date(lead.createdAt), "MMM d, yyyy 'at' h:mm a")}
            />
            <DetailRow
              icon={<MessageSquare className="h-4 w-4" />}
              label="Notes"
              value={`${lead.notesCount} ${lead.notesCount === 1 ? "note" : "notes"}`}
            />
          </CardContent>
        </Card>

        <Card className="border-gray-200/80 shadow-sm lg:col-span-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Activity timeline</CardTitle>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="space-y-2">
              <Textarea
                value={noteText}
                onChange={(e) => setNoteText(e.target.value)}
                placeholder="Log a call, meeting, or thought..."
                className="min-h-[90px] resize-none"
                data-testid="input-note"
              />
              <div className="flex justify-end">
                <Button
                  size="sm"
                  onClick={() =>
                    noteText.trim() &&
                    addNoteMut.mutate({ id: lead.id, data: { text: noteText.trim() } })
                  }
                  disabled={!noteText.trim() || addNoteMut.isPending}
                  data-testid="button-add-note"
                >
                  <Send className="mr-2 h-3.5 w-3.5" />
                  {addNoteMut.isPending ? "Adding..." : "Add note"}
                </Button>
              </div>
            </div>

            {lead.notes.length === 0 ? (
              <div className="py-10 text-center border-t border-gray-100">
                <MessageSquare className="mx-auto h-8 w-8 text-gray-300" />
                <p className="mt-2 text-sm font-medium text-gray-700">
                  No notes yet
                </p>
                <p className="mt-1 text-xs text-gray-500">
                  Add your first note above to start the timeline.
                </p>
              </div>
            ) : (
              <ol className="relative border-l border-gray-200 ml-2 space-y-5 pt-2">
                {lead.notes.map((n) => (
                  <li
                    key={n.id}
                    className="ml-5"
                    data-testid={`note-${n.id}`}
                  >
                    <span className="absolute -left-[7px] mt-1.5 h-3 w-3 rounded-full bg-white border-2 border-indigo-500" />
                    <div className="bg-gray-50/60 border border-gray-100 rounded-lg p-3">
                      <p className="text-xs text-gray-500 mb-1">
                        {format(new Date(n.createdAt), "MMM d, yyyy 'at' h:mm a")}
                        {" · "}
                        {formatDistanceToNow(new Date(n.createdAt), {
                          addSuffix: true,
                        })}
                      </p>
                      <p className="text-sm text-gray-800 whitespace-pre-wrap">
                        {n.text}
                      </p>
                    </div>
                  </li>
                ))}
              </ol>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function DetailRow({
  icon,
  label,
  value,
}: {
  icon: React.ReactNode;
  label: string;
  value: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-3">
      <div className="h-7 w-7 rounded-md bg-gray-50 flex items-center justify-center text-gray-500 shrink-0">
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-xs text-gray-500">{label}</p>
        <p className="text-sm text-gray-900 mt-0.5 break-words">{value}</p>
      </div>
    </div>
  );
}
