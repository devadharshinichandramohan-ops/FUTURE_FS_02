import { Link } from "wouter";
import {
  useGetAnalyticsSummary,
  useGetRecentActivity,
  useListLeads,
  getGetAnalyticsSummaryQueryKey,
  getGetRecentActivityQueryKey,
  getListLeadsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import {
  Users,
  UserPlus,
  PhoneCall,
  Trophy,
  ArrowUpRight,
  Activity,
  MessageSquare,
  CircleDot,
} from "lucide-react";
import { formatDistanceToNow } from "date-fns";

const sourceColors: Record<string, string> = {
  website: "bg-indigo-500",
  referral: "bg-emerald-500",
  ads: "bg-amber-500",
};

const statusBadge: Record<string, string> = {
  new: "bg-blue-50 text-blue-700 border-blue-200",
  contacted: "bg-amber-50 text-amber-700 border-amber-200",
  converted: "bg-emerald-50 text-emerald-700 border-emerald-200",
};

export default function Dashboard() {
  const { data: summary, isLoading: summaryLoading } = useGetAnalyticsSummary({
    query: { queryKey: getGetAnalyticsSummaryQueryKey() },
  });
  const { data: activity, isLoading: activityLoading } = useGetRecentActivity({
    query: { queryKey: getGetRecentActivityQueryKey() },
  });
  const { data: leads, isLoading: leadsLoading } = useListLeads(undefined, {
    query: { queryKey: getListLeadsQueryKey() },
  });

  const recentLeads = (leads ?? []).slice(0, 5);
  const maxSource = Math.max(
    1,
    ...(summary?.leadsBySource ?? []).map((s) => s.count),
  );

  return (
    <div className="px-8 py-8 max-w-[1400px] mx-auto">
      <div className="flex items-end justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-gray-900">
            Dashboard
          </h1>
          <p className="text-sm text-gray-500 mt-1">
            A snapshot of your pipeline today.
          </p>
        </div>
        <Link href="/leads">
          <Button data-testid="link-view-leads">
            View all leads
            <ArrowUpRight className="ml-2 h-4 w-4" />
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <StatCard
          label="Total leads"
          value={summary?.totalLeads ?? 0}
          icon={<Users className="h-4 w-4" />}
          loading={summaryLoading}
          tone="indigo"
        />
        <StatCard
          label="New"
          value={summary?.newLeads ?? 0}
          icon={<UserPlus className="h-4 w-4" />}
          loading={summaryLoading}
          tone="blue"
        />
        <StatCard
          label="Contacted"
          value={summary?.contactedLeads ?? 0}
          icon={<PhoneCall className="h-4 w-4" />}
          loading={summaryLoading}
          tone="amber"
        />
        <StatCard
          label="Converted"
          value={summary?.convertedLeads ?? 0}
          icon={<Trophy className="h-4 w-4" />}
          loading={summaryLoading}
          tone="emerald"
          suffix={
            summary
              ? `${summary.conversionRate.toFixed(1)}% conversion`
              : undefined
          }
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2 border-gray-200/80 shadow-sm">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <div>
              <CardTitle className="text-base">Recent leads</CardTitle>
              <p className="text-xs text-gray-500 mt-0.5">
                Latest signals from your inbound channels
              </p>
            </div>
            <Link href="/leads">
              <Button variant="ghost" size="sm" className="text-gray-500">
                View all
                <ArrowUpRight className="ml-1 h-3 w-3" />
              </Button>
            </Link>
          </CardHeader>
          <CardContent className="pt-0">
            {leadsLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-12 w-full" />
                ))}
              </div>
            ) : recentLeads.length === 0 ? (
              <div className="py-12 text-center">
                <Users className="mx-auto h-10 w-10 text-gray-300" />
                <p className="mt-3 text-sm font-medium text-gray-700">
                  No leads yet
                </p>
                <p className="mt-1 text-xs text-gray-500">
                  Once a lead lands, it'll show up here.
                </p>
              </div>
            ) : (
              <div className="divide-y divide-gray-100">
                {recentLeads.map((lead) => (
                  <Link key={lead.id} href={`/leads/${lead.id}`}>
                    <div
                      className="flex items-center justify-between py-3 hover:bg-gray-50/60 -mx-2 px-2 rounded-md cursor-pointer transition-colors"
                      data-testid={`row-lead-${lead.id}`}
                    >
                      <div className="flex items-center gap-3 min-w-0">
                        <div className="h-9 w-9 rounded-full bg-gradient-to-br from-indigo-100 to-indigo-200 flex items-center justify-center text-xs font-semibold text-indigo-700">
                          {lead.name.charAt(0).toUpperCase()}
                        </div>
                        <div className="min-w-0">
                          <p className="text-sm font-medium text-gray-900 truncate">
                            {lead.name}
                          </p>
                          <p className="text-xs text-gray-500 truncate">
                            {lead.email}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="text-xs text-gray-500 capitalize hidden sm:inline">
                          {lead.source}
                        </span>
                        <Badge
                          variant="outline"
                          className={`text-xs capitalize border ${statusBadge[lead.status]}`}
                        >
                          {lead.status}
                        </Badge>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="border-gray-200/80 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Leads by source</CardTitle>
            <p className="text-xs text-gray-500 mt-0.5">
              Where your pipeline is coming from
            </p>
          </CardHeader>
          <CardContent className="pt-0">
            {summaryLoading ? (
              <div className="space-y-4">
                {Array.from({ length: 3 }).map((_, i) => (
                  <Skeleton key={i} className="h-8 w-full" />
                ))}
              </div>
            ) : (summary?.leadsBySource ?? []).length === 0 ? (
              <p className="text-sm text-gray-500 py-6 text-center">
                No data yet
              </p>
            ) : (
              <div className="space-y-4">
                {summary!.leadsBySource.map((s) => (
                  <div key={s.source} data-testid={`source-${s.source}`}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-sm font-medium text-gray-700 capitalize">
                        {s.source}
                      </span>
                      <span className="text-sm tabular-nums text-gray-900 font-semibold">
                        {s.count}
                      </span>
                    </div>
                    <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full ${sourceColors[s.source] ?? "bg-gray-400"} rounded-full transition-all`}
                        style={{
                          width: `${(s.count / maxSource) * 100}%`,
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card className="lg:col-span-3 border-gray-200/80 shadow-sm">
          <CardHeader className="pb-3">
            <CardTitle className="text-base flex items-center gap-2">
              <Activity className="h-4 w-4 text-indigo-600" />
              Recent activity
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            {activityLoading ? (
              <div className="space-y-3">
                {Array.from({ length: 4 }).map((_, i) => (
                  <Skeleton key={i} className="h-10 w-full" />
                ))}
              </div>
            ) : (activity ?? []).length === 0 ? (
              <p className="text-sm text-gray-500 py-6 text-center">
                Quiet for now. Activity will appear as your team works leads.
              </p>
            ) : (
              <ul className="space-y-3">
                {activity!.map((item) => (
                  <li
                    key={item.id}
                    className="flex items-start gap-3"
                    data-testid={`activity-${item.id}`}
                  >
                    <div
                      className={`mt-1 h-7 w-7 rounded-full flex items-center justify-center shrink-0 ${
                        item.type === "lead_created"
                          ? "bg-indigo-50 text-indigo-600"
                          : item.type === "note_added"
                            ? "bg-amber-50 text-amber-600"
                            : "bg-emerald-50 text-emerald-600"
                      }`}
                    >
                      {item.type === "lead_created" ? (
                        <UserPlus className="h-3.5 w-3.5" />
                      ) : item.type === "note_added" ? (
                        <MessageSquare className="h-3.5 w-3.5" />
                      ) : (
                        <CircleDot className="h-3.5 w-3.5" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm text-gray-900">
                        <Link href={`/leads/${item.leadId}`}>
                          <span className="font-medium hover:text-indigo-600 cursor-pointer">
                            {item.leadName}
                          </span>
                        </Link>
                        <span className="text-gray-500"> · {item.message}</span>
                      </p>
                      <p className="text-xs text-gray-400 mt-0.5">
                        {formatDistanceToNow(new Date(item.createdAt), {
                          addSuffix: true,
                        })}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({
  label,
  value,
  icon,
  loading,
  tone,
  suffix,
}: {
  label: string;
  value: number;
  icon: React.ReactNode;
  loading: boolean;
  tone: "indigo" | "blue" | "amber" | "emerald";
  suffix?: string;
}) {
  const tones: Record<string, string> = {
    indigo: "bg-indigo-50 text-indigo-600",
    blue: "bg-blue-50 text-blue-600",
    amber: "bg-amber-50 text-amber-600",
    emerald: "bg-emerald-50 text-emerald-600",
  };
  return (
    <Card
      className="border-gray-200/80 shadow-sm"
      data-testid={`stat-${label.toLowerCase().replace(/\s/g, "-")}`}
    >
      <CardContent className="p-5">
        <div className="flex items-start justify-between">
          <div>
            <p className="text-xs font-medium uppercase tracking-wide text-gray-500">
              {label}
            </p>
            {loading ? (
              <Skeleton className="h-8 w-16 mt-2" />
            ) : (
              <p className="text-3xl font-bold text-gray-900 mt-1 tabular-nums">
                {value}
              </p>
            )}
            {suffix && !loading && (
              <p className="text-xs text-gray-500 mt-1">{suffix}</p>
            )}
          </div>
          <div className={`h-9 w-9 rounded-lg flex items-center justify-center ${tones[tone]}`}>
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
