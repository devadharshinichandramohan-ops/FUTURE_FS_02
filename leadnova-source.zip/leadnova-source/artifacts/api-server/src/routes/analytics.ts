import { Router, type IRouter } from "express";
import { db, leadsTable, leadNotesTable } from "@workspace/db";
import { desc, eq, sql } from "drizzle-orm";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();

router.use(requireAuth);

router.get("/analytics/summary", async (_req, res) => {
  const [{ total }] = await db
    .select({ total: sql<number>`COUNT(*)::int` })
    .from(leadsTable);

  const [{ newCount }] = await db
    .select({ newCount: sql<number>`COUNT(*)::int` })
    .from(leadsTable)
    .where(eq(leadsTable.status, "new"));

  const [{ contacted }] = await db
    .select({ contacted: sql<number>`COUNT(*)::int` })
    .from(leadsTable)
    .where(eq(leadsTable.status, "contacted"));

  const [{ converted }] = await db
    .select({ converted: sql<number>`COUNT(*)::int` })
    .from(leadsTable)
    .where(eq(leadsTable.status, "converted"));

  const bySource = await db
    .select({
      source: leadsTable.source,
      count: sql<number>`COUNT(*)::int`,
    })
    .from(leadsTable)
    .groupBy(leadsTable.source);

  const totalNum = total ?? 0;
  const convertedNum = converted ?? 0;
  const conversionRate =
    totalNum > 0 ? Math.round((convertedNum / totalNum) * 1000) / 10 : 0;

  res.json({
    totalLeads: totalNum,
    newLeads: newCount ?? 0,
    contactedLeads: contacted ?? 0,
    convertedLeads: convertedNum,
    conversionRate,
    leadsBySource: bySource.map((r) => ({
      source: r.source,
      count: r.count ?? 0,
    })),
  });
});

router.get("/analytics/recent-activity", async (_req, res) => {
  const recentLeads = await db
    .select({
      id: leadsTable.id,
      name: leadsTable.name,
      createdAt: leadsTable.createdAt,
    })
    .from(leadsTable)
    .orderBy(desc(leadsTable.createdAt))
    .limit(10);

  const recentNotes = await db
    .select({
      id: leadNotesTable.id,
      leadId: leadNotesTable.leadId,
      text: leadNotesTable.text,
      createdAt: leadNotesTable.createdAt,
      leadName: leadsTable.name,
    })
    .from(leadNotesTable)
    .innerJoin(leadsTable, eq(leadsTable.id, leadNotesTable.leadId))
    .orderBy(desc(leadNotesTable.createdAt))
    .limit(10);

  type Item = {
    id: string;
    type: "lead_created" | "note_added";
    leadId: string;
    leadName: string;
    message: string;
    createdAt: string;
    _ts: number;
  };

  const items: Item[] = [
    ...recentLeads.map((l) => ({
      id: `lead-${l.id}`,
      type: "lead_created" as const,
      leadId: l.id,
      leadName: l.name,
      message: `${l.name} was added as a new lead`,
      createdAt: l.createdAt.toISOString(),
      _ts: l.createdAt.getTime(),
    })),
    ...recentNotes.map((n) => ({
      id: `note-${n.id}`,
      type: "note_added" as const,
      leadId: n.leadId,
      leadName: n.leadName,
      message:
        n.text.length > 120 ? `${n.text.slice(0, 117)}...` : n.text,
      createdAt: n.createdAt.toISOString(),
      _ts: n.createdAt.getTime(),
    })),
  ];

  items.sort((a, b) => b._ts - a._ts);
  res.json(items.slice(0, 15).map(({ _ts, ...rest }) => rest));
});

export default router;
