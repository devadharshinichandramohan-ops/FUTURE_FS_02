import { Router, type IRouter } from "express";
import { db, leadsTable, leadNotesTable } from "@workspace/db";
import { and, desc, eq, ilike, or, sql } from "drizzle-orm";
import {
  CreateLeadBody,
  UpdateLeadBody,
  AddLeadNoteBody,
  ListLeadsQueryParams,
} from "@workspace/api-zod";
import { requireAuth } from "../lib/auth";

const router: IRouter = Router();

router.use(requireAuth);

router.get("/leads", async (req, res) => {
  const parsed = ListLeadsQueryParams.safeParse(req.query);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid query" });
    return;
  }
  const { search, status } = parsed.data;

  const conditions = [];
  if (search && search.trim()) {
    const q = `%${search.trim()}%`;
    const orExpr = or(ilike(leadsTable.name, q), ilike(leadsTable.email, q));
    if (orExpr) conditions.push(orExpr);
  }
  if (status) conditions.push(eq(leadsTable.status, status));

  const rows = await db
    .select()
    .from(leadsTable)
    .where(conditions.length ? and(...conditions) : undefined)
    .orderBy(desc(leadsTable.createdAt));

  const counts = await db
    .select({
      leadId: leadNotesTable.leadId,
      count: sql<number>`COUNT(*)::int`,
    })
    .from(leadNotesTable)
    .groupBy(leadNotesTable.leadId);

  const countMap = new Map(counts.map((c) => [c.leadId, c.count ?? 0]));

  res.json(
    rows.map((r) => ({
      id: r.id,
      name: r.name,
      email: r.email,
      source: r.source,
      status: r.status,
      notesCount: countMap.get(r.id) ?? 0,
      createdAt: r.createdAt.toISOString(),
    })),
  );
});

router.post("/leads", async (req, res) => {
  const parsed = CreateLeadBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid request" });
    return;
  }
  const [lead] = await db
    .insert(leadsTable)
    .values({
      name: parsed.data.name.trim(),
      email: parsed.data.email.trim().toLowerCase(),
      source: parsed.data.source,
    })
    .returning();
  res.status(201).json({
    id: lead.id,
    name: lead.name,
    email: lead.email,
    source: lead.source,
    status: lead.status,
    notesCount: 0,
    createdAt: lead.createdAt.toISOString(),
  });
});

router.get("/leads/:id", async (req, res) => {
  const id = req.params.id;
  const [lead] = await db
    .select()
    .from(leadsTable)
    .where(eq(leadsTable.id, id))
    .limit(1);
  if (!lead) {
    res.status(404).json({ message: "Lead not found" });
    return;
  }
  const notes = await db
    .select()
    .from(leadNotesTable)
    .where(eq(leadNotesTable.leadId, id))
    .orderBy(desc(leadNotesTable.createdAt));
  res.json({
    id: lead.id,
    name: lead.name,
    email: lead.email,
    source: lead.source,
    status: lead.status,
    notesCount: notes.length,
    createdAt: lead.createdAt.toISOString(),
    notes: notes.map((n) => ({
      id: n.id,
      leadId: n.leadId,
      text: n.text,
      createdAt: n.createdAt.toISOString(),
    })),
  });
});

router.put("/leads/:id", async (req, res) => {
  const id = req.params.id;
  const parsed = UpdateLeadBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid request" });
    return;
  }
  const updates: Record<string, unknown> = {};
  if (parsed.data.name !== undefined) updates.name = parsed.data.name.trim();
  if (parsed.data.email !== undefined)
    updates.email = parsed.data.email.trim().toLowerCase();
  if (parsed.data.source !== undefined) updates.source = parsed.data.source;
  if (parsed.data.status !== undefined) updates.status = parsed.data.status;

  if (Object.keys(updates).length === 0) {
    res.status(400).json({ message: "No fields to update" });
    return;
  }

  const [lead] = await db
    .update(leadsTable)
    .set(updates)
    .where(eq(leadsTable.id, id))
    .returning();
  if (!lead) {
    res.status(404).json({ message: "Lead not found" });
    return;
  }
  const [{ count }] = await db
    .select({ count: sql<number>`COUNT(*)::int` })
    .from(leadNotesTable)
    .where(eq(leadNotesTable.leadId, id));
  res.json({
    id: lead.id,
    name: lead.name,
    email: lead.email,
    source: lead.source,
    status: lead.status,
    notesCount: count ?? 0,
    createdAt: lead.createdAt.toISOString(),
  });
});

router.delete("/leads/:id", async (req, res) => {
  const id = req.params.id;
  const result = await db.delete(leadsTable).where(eq(leadsTable.id, id)).returning();
  if (result.length === 0) {
    res.status(404).json({ message: "Lead not found" });
    return;
  }
  res.json({ success: true });
});

router.post("/leads/:id/notes", async (req, res) => {
  const id = req.params.id;
  const parsed = AddLeadNoteBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ message: "Invalid request" });
    return;
  }
  const [lead] = await db
    .select({ id: leadsTable.id })
    .from(leadsTable)
    .where(eq(leadsTable.id, id))
    .limit(1);
  if (!lead) {
    res.status(404).json({ message: "Lead not found" });
    return;
  }
  const [note] = await db
    .insert(leadNotesTable)
    .values({ leadId: id, text: parsed.data.text.trim() })
    .returning();
  res.status(201).json({
    id: note.id,
    leadId: note.leadId,
    text: note.text,
    createdAt: note.createdAt.toISOString(),
  });
});

export default router;
