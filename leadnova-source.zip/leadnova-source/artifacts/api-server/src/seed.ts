import bcrypt from "bcryptjs";
import { db, usersTable, leadsTable, leadNotesTable } from "@workspace/db";
import { eq, sql } from "drizzle-orm";
import { logger } from "./lib/logger";

const ADMIN_EMAIL = "admin@leadnova.com";
const ADMIN_PASSWORD = "admin123";

export async function seed(): Promise<void> {
  const [existing] = await db
    .select({ id: usersTable.id })
    .from(usersTable)
    .where(eq(usersTable.email, ADMIN_EMAIL))
    .limit(1);

  if (!existing) {
    const passwordHash = await bcrypt.hash(ADMIN_PASSWORD, 10);
    await db.insert(usersTable).values({
      name: "LeadNova Admin",
      email: ADMIN_EMAIL,
      passwordHash,
      role: "admin",
    });
    logger.info({ email: ADMIN_EMAIL }, "Seeded admin user");
  }

  const [{ count }] = await db
    .select({ count: sql<number>`COUNT(*)::int` })
    .from(leadsTable);

  if ((count ?? 0) === 0) {
    const sample = [
      {
        name: "Jonathan Harker",
        email: "j.harker@transtech.com",
        source: "referral" as const,
        status: "contacted" as const,
        note: "Demo meeting completed. Liked the AI-driven prospecting tool. Concerned about initial setup time.",
      },
      {
        name: "Mina Murray",
        email: "mina@whitbypress.com",
        source: "website" as const,
        status: "new" as const,
        note: null,
      },
      {
        name: "Abraham Van Helsing",
        email: "vanhelsing@amsterdam-clinic.nl",
        source: "ads" as const,
        status: "converted" as const,
        note: "Signed annual plan. Onboarding kicks off Monday.",
      },
      {
        name: "Lucy Westenra",
        email: "lucy@hillingham.co.uk",
        source: "referral" as const,
        status: "new" as const,
        note: null,
      },
      {
        name: "Quincey Morris",
        email: "quincey@texasranch.com",
        source: "website" as const,
        status: "contacted" as const,
        note: "Sent enterprise pricing guide. Awaiting response.",
      },
    ];

    for (const s of sample) {
      const [lead] = await db
        .insert(leadsTable)
        .values({
          name: s.name,
          email: s.email,
          source: s.source,
          status: s.status,
        })
        .returning();
      if (s.note) {
        await db
          .insert(leadNotesTable)
          .values({ leadId: lead.id, text: s.note });
      }
    }
    logger.info({ count: sample.length }, "Seeded sample leads");
  }
}
